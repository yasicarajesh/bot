import React from 'react';


class Test extends React.Component{
  render(){
    return(
         <> 
                                   <section id="testimonial" class="section-padding">
                                    <div class="container">
                                    <div class="row">
                                        <div class="col-md-12">
                                        <h2 class="ser-title">see what patients are saying?</h2>
                                        <hr class="botm-line"/>
                                        </div>
                                        <div class="col-md-4 col-sm-4">
                                        <div class="testi-details">
                                            
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                        </div>
                                        <div class="testi-info">
                                            
                                            <a href="#"><img src="asserts/img/thumb.png" alt="" class="img-responsive"/></a>
                                            
                                            <h3>Alex<span>Texas</span></h3>
                                        </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4">
                                        <div class="testi-details">
                                            
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                        </div>
                                        <div class="testi-info">
                                            
                                            <a href="#"><img src="asserts/img/thumb.png" alt="" class="img-responsive"/></a>
                                            
                                            <h3>Alex<span>Texas</span></h3>
                                        </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4">
                                        <div class="testi-details">
                                            
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                        </div>
                                        <div class="testi-info">
                                            
                                            <a href="#"><img src="asserts/img/thumb.png" alt="" class="img-responsive"/></a>
                                            
                                            <h3>Alex<span>Texas</span></h3>
                                        </div>
                                        </div>
                                    </div>
                                    </div>
                                </section>
            </>
    );
  }
}
export default Test;